package com.beezer.DublinAirportArrivals;

public class Flight {

	public Flight(String singleRowArray[]) {
		String origin = singleRowArray[0];
		String airline1 = singleRowArray[1];
		String airline2 = singleRowArray[2];
		String flightNo = singleRowArray[3];
		String date = singleRowArray[4];
		String ArrTime = singleRowArray[5];
		String status = singleRowArray[6];
		
	}

}
